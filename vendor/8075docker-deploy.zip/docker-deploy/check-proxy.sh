#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 || $# -gt 3 ]]; then
  echo "用法: $0 PROXY_HOST:PORT USER [次数]" >&2
  echo "密码通过交互提示输入，不会出现在命令行历史中。" >&2
  exit 2
fi

command -v curl >/dev/null 2>&1 || {
  echo "错误：需要先安装 curl" >&2
  exit 1
}

proxy_addr=$1
proxy_user=$2
attempts=${3:-5}
case "$attempts" in
  ''|*[!0-9]*) echo "错误：次数必须是正整数" >&2; exit 2 ;;
esac
(( attempts > 0 )) || {
  echo "错误：次数必须大于 0" >&2
  exit 2
}

read -r -s -p "代理密码: " proxy_password
echo

success=0
for ((i=1; i<=attempts; i++)); do
  result=$(curl -sS -o /dev/null \
    --connect-timeout 8 \
    --max-time 20 \
    --socks5-hostname "$proxy_addr" \
    --proxy-user "$proxy_user:$proxy_password" \
    -w 'HTTP %{http_code}, connect=%{time_connect}s, total=%{time_total}s' \
    http://extshort.weixin.qq.com/ 2>&1) && status=0 || status=$?
  if [[ $status -eq 0 && "$result" == HTTP\ 302,* ]]; then
    ((success+=1))
    printf '[%d/%d] 成功：%s\n' "$i" "$attempts" "$result"
  else
    printf '[%d/%d] 失败：%s\n' "$i" "$attempts" "$result"
  fi
done

printf '结果：%d/%d 成功。\n' "$success" "$attempts"
if (( success != attempts )); then
  echo "该节点存在连接拒绝、超时或重置，可能导致 GetQR/CheckUuid 转圈。"
  exit 1
fi

echo "基础 SOCKS5 链路正常；最终仍需用 GetQR 验证微信 MMTLS 业务请求。"
