# WeChatPadProBusiness Docker 部署

本目录用于全新 Linux 服务器部署。业务容器使用 `network_mode: host`，因此 SOCKS5、
DNS、IPv4/IPv6、路由和出口与宿主机一致，不再经过 Docker bridge NAT。

## 1. 环境要求

- Linux x86-64 服务器。不要在 macOS/Windows Docker Desktop 上使用本配置。
- Docker Engine 24+ 与 Docker Compose v2.20+。
- 可用端口：`18062`、`18089`、`18080`、`16379`。
- 生产环境公网只开放 HTTPS 反向代理端口；`18080` 仅对白名单手机来源 IP 开放。
- `18062`、`18089` 不应在公网安全组中直接对所有来源开放。
- `16379` 是项目独立 Redis，仅绑定 `127.0.0.1`，不要开放到公网。

检查环境：

```bash
uname -m
docker version
docker compose version
```

`uname -m` 应返回 `x86_64`。

## 2. 首次安装

进入本目录：

```bash
cd docker-deploy
```

不需要手动创建真实配置。首次运行时，`install.sh` 会从
`config/app.conf.example` 创建权限为 `600` 的 `config/app.conf`。默认端口和 Redis
配置已经适配 host 网络：

```ini
httpaddr = "0.0.0.0"
httpport = 18062
websocketport = 18089
pad_face_verifier_port = 18080
redislink = 127.0.0.1:16379
```

私有镜像第一次使用需要登录。密码提示处输入 Docker Hub 访问令牌，不要把令牌写进
Compose、脚本或命令行：

```bash
docker login -u wechatpadpro
```

执行一键安装：

```bash
chmod +x install.sh check-proxy.sh
./install.sh
```

当 `config/app.conf` 中的 `user_token_key` 为空时，安装脚本会引导完成凭证配置：

1. 打开 [访问控制](https://adminmax.knowhub.cloud/user/access-tokens) 并登录。
2. 在 `access-tokens` 页面创建客户端密钥。密钥仅完整显示一次，请立即保存。
3. 返回终端并按回车，粘贴客户端密钥。输入过程不会回显密钥内容。
4. 输入 `y` 确认后，脚本自动写入 `config/app.conf` 并继续安装。

一个客户端密钥只对应一套服务器部署。新增服务器、迁移后同时保留旧服务器或搭建测试
环境时，都应单独创建新密钥，不能让多套运行实例共用同一个密钥。

已有客户端密钥的高级用户也可以在执行脚本前手动配置：

```ini
user_token_key = "客户自己的客户端密钥"
```

安装脚本会自动完成：

1. 检查 Linux、x86-64、Docker 和 Compose。
2. 引导创建并写入客户端密钥，再检查配置格式、端口重复和宿主机端口占用。
3. 在停止旧部署前拉取指定镜像，再强制重建服务，使最新配置真正生效。
4. 等待 `prepare` 完成后，以非 root 用户启动 Redis；首次安装会自动生成独立密码。
5. 等待 API 就绪，并显示镜像名、版本、Build ID、Image ID 和 Repo Digest。

所有业务配置只读取 `config/app.conf`，不使用 `docker.env`。持久数据位置：

```text
config/app.conf      运行配置和自动生成的 Redis 密码
data/wechatpad/      登录会话、设备身份和人脸 CA
data/redis/          Redis 持久数据
```

## 3. 验证服务

```bash
docker compose -f docker-compose.release.yml ps
docker compose -f docker-compose.release.yml logs --tail=100 wechatpad
curl -I http://127.0.0.1:18062/
```

host 网络模式下，`docker compose ps` 的 `PORTS` 列为空是正常现象。实际监听端口来自
`config/app.conf`，可用下面的命令确认：

```bash
ss -ltnp | grep -E ':(18062|18089|18080|16379)\b'
```

宿主机本地验证：

```text
http://127.0.0.1:18062/
```

生产环境应使用 HTTPS 反向代理访问 API 和文档，并使用 WSS 连接 WebSocket。不要通过公网
明文 HTTP/WS 长期传递 Access Token。确需临时联调公网 HTTP 时，只能在防火墙中限制到
测试人员的来源 IP，测试结束立即关闭。

浏览器 WebSocket 不直接在 URL 中携带 Access Token。先通过带认证头的 HTTPS API 调用
`/api/Runtime/WebSocketTicket` 换取短时票据，再连接：

```text
wss://YOUR_DOMAIN/ws/sync?ticket=SHORT_LIVED_TICKET
```

## 4. SOCKS5 代理正确写法

GetQR 请求中可以使用不带前缀的 `IP:端口`，默认按 SOCKS5 处理：

```json
{
  "DeviceName": "我的iPad",
  "Proxy": {
    "ProxyIp": "203.0.113.10:1080",
    "ProxyUser": "代理用户名",
    "ProxyPassword": "代理密码"
  },
  "oversea": false
}
```

也支持明确写成：

```json
"ProxyIp": "socks5://203.0.113.10:1080"
```

注意：

- 不要写 `wss://`，WSS 不是 SOCKS5 代理协议。
- `socks5://` 与 `socks5h://` 都支持；目标域名由 SOCKS5 服务端解析。
- 如果供应商明确给的是 HTTP 代理，使用 `http://IP:端口`。
- 用户名和密码不要包含多余空格、转义反斜杠或 Markdown 的 `\_`。
- 使用 IP 白名单认证时，应把服务器公网出口 IP 加入代理商白名单。
- `Proxy` 是每次 GetQR 请求的业务参数，不是 `app.conf` 的全局配置。

在服务器宿主机执行代理基础检测：

```bash
./check-proxy.sh 203.0.113.10:1080 '代理用户名' 5
```

脚本会安全提示输入密码，并连续测试五次。应达到 `5/5` 且返回 HTTP 302。这个检测只证明
基础 SOCKS5 链路可用，最终仍要以 GetQR 和扫码后的 CheckUuid 成功为准。

## 5. 人脸代理与证书

主程序会自动启动同镜像内的 `pad-face-verify-linux-x64`，不需要用户再开一个进程。
默认人脸代理端口是 `18080`，桥接地址会自动指向本机 API `18062`。

首次在一台手机上使用时，需要安装当前服务器生成的 WeChatPadPro CA。证书属于这套部署，
不是每个微信账号一张；同一套服务的多个使用者可以安装同一张证书。重新删除
`data/wechatpad/` 或更换部署数据目录后可能生成新证书，手机需要重新安装并信任。

生产环境应配置 HTTPS 反向代理，并在 `config/app.conf` 填写固定公网地址：

```ini
pad_face_public_base_url = "https://YOUR_DOMAIN"
```

不要填写容器内部地址。人脸代理端口 `18080` 不应向全网开放，必须通过云安全组或防火墙
只允许当前实际验证手机的公网来源 IP；手机网络变化后需要同步更新白名单。

## 6. 常用运维命令

查看状态和日志：

```bash
docker compose -f docker-compose.release.yml ps
docker compose -f docker-compose.release.yml logs -f --tail=200 wechatpad
docker compose -f docker-compose.release.yml logs -f --tail=100 redis
```

仅重启未改配置的业务进程：

```bash
docker compose -f docker-compose.release.yml restart wechatpad
```

停止但保留数据：

```bash
docker compose -f docker-compose.release.yml down
```

升级镜像、修改配置或重新部署时，统一执行安装脚本。脚本会先拉取镜像，随后停止旧容器并
使用 `--force-recreate` 重建，避免继续使用旧的配置挂载：

```bash
cp config/app.conf "config/app.conf.backup-$(date +%Y%m%d_%H%M%S)"
./install.sh
```

需要锁定其他镜像版本时，通过环境变量指定，不修改 Compose：

```bash
WECHATPAD_IMAGE=wechatpadpro/wechatpadprobusiness:版本标签 ./install.sh
```

升级和重启都不要删除 `config/` 与 `data/`。它们包含用户配置、Redis 数据、设备身份、
登录会话和人脸 CA。

## 7. 代理故障判断

| 日志或现象 | 含义 | 处理 |
|---|---|---|
| `connection refused` | 代理端口拒绝连接 | 检查节点状态、端口和白名单 |
| `general SOCKS server failure` | SOCKS5 服务端拒绝目标连接 | 联系代理商或更换节点 |
| `connection reset by peer` / `EOF` | 代理节点中途断开 | 更换更稳定的长效 SOCKS5 |
| `timeout awaiting response headers` | 已发出请求但代理/上游未及时返回 | 连续检测节点质量，避免只测一次 |
| GetQR 成功但扫码一直转圈 | CheckUuid 后续轮询被代理中断 | 查看同一时段 MMTLS 日志并更换节点 |
| 不使用 Proxy 时成功、使用 Proxy 时失败 | 应用和微信直连正常，故障在代理链路 | 不要继续修改 Redis 或业务端口 |

DNS 故障通常会明确出现 `no such host`。如果日志是 `reset`、`EOF`、`SOCKS server
failure`，继续修改 DNS 无法解决。

## 8. 安全事项

- Docker Hub Token、客户端密钥、代理账号密码都属于敏感凭证，泄露后立即轮换。
- 不要把 `config/app.conf`、`data/` 或带真实密码的请求体提交到 Git。
- 一个客户端密钥只绑定一套部署，不允许多个服务器或测试环境共用。
- 公网 API 使用 HTTPS，WebSocket 使用 WSS 和短时 ticket，不在 URL 中传 Access Token。
- `18080` 是手机人脸验证代理入口，必须使用安全组或防火墙限制来源 IP。
- Redis `16379` 必须保持绑定 `127.0.0.1`，不要改成 `0.0.0.0`。
