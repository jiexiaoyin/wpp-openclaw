#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
COMPOSE_FILE="$SCRIPT_DIR/docker-compose.release.yml"
CONFIG_FILE="$SCRIPT_DIR/config/app.conf"
CONFIG_TEMPLATE="$SCRIPT_DIR/config/app.conf.example"
ACCESS_TOKEN_URL="https://adminmax.knowhub.cloud/user/access-tokens"

fail() {
  printf '错误：%s\n' "$*" >&2
  exit 1
}

read_config() {
  awk -v wanted="$1" '
    /^[[:space:]]*[#;]/ { next }
    {
      pos = index($0, "=")
      if (pos == 0) next
      key = substr($0, 1, pos - 1)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", key)
      if (key != wanted) next
      value = substr($0, pos + 1)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
      if (value ~ /^".*"$/) value = substr(value, 2, length(value) - 2)
      print value
      exit
    }
  ' "$CONFIG_FILE"
}

ensure_config_file() {
  if [ -f "$CONFIG_FILE" ]; then
    chmod 600 "$CONFIG_FILE" || fail "无法设置 config/app.conf 的安全权限"
    return 0
  fi
  [ -f "$CONFIG_TEMPLATE" ] || fail "缺少 config/app.conf.example"
  umask 077
  cp "$CONFIG_TEMPLATE" "$CONFIG_FILE" || fail "无法从 config/app.conf.example 创建 config/app.conf"
  chmod 600 "$CONFIG_FILE" || fail "无法设置 config/app.conf 的安全权限"
  printf '已从 config/app.conf.example 创建私有配置 config/app.conf。\n'
}

compose_version_supported() {
  version=$1
  version=${version#v}
  major=${version%%.*}
  remainder=${version#*.}
  minor=${remainder%%.*}
  case "$major" in ''|*[!0-9]*) return 1 ;; esac
  case "$minor" in ''|*[!0-9]*) return 1 ;; esac
  [ "$major" -gt 2 ] || { [ "$major" -eq 2 ] && [ "$minor" -ge 20 ]; }
}

metadata_or_unknown() {
  case "${1:-}" in
    ''|'<no value>'|'[]'|'null') printf '%s\n' "未知" ;;
    *) printf '%s\n' "$1" ;;
  esac
}

write_config_value() {
  config_key=$1
  config_value=$2
  config_dir=${CONFIG_FILE%/*}
  config_temp=
  config_secret=
  cleanup_config_temp() {
    [ -z "${config_temp:-}" ] || rm -f "$config_temp"
    [ -z "${config_secret:-}" ] || rm -f "$config_secret"
  }
  trap 'cleanup_config_temp' 0
  trap 'cleanup_config_temp; exit 130' 1 2 15

  config_temp=$(mktemp "$config_dir/.app.conf.tmp.XXXXXX") || fail "无法创建配置临时文件"
  config_secret=$(mktemp "$config_dir/.app.conf.secret.XXXXXX") || fail "无法创建密钥临时文件"
  chmod 600 "$config_secret" || fail "无法设置密钥临时文件权限"
  printf '%s\n' "$config_value" > "$config_secret"

  if ! awk -v wanted="$config_key" -v secret_file="$config_secret" '
    BEGIN {
      if ((getline replacement < secret_file) <= 0) exit 2
      close(secret_file)
      updated = 0
    }
    {
      pos = index($0, "=")
      key = pos == 0 ? "" : substr($0, 1, pos - 1)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", key)
      if (key == wanted) {
        print wanted " = \"" replacement "\""
        updated = 1
        next
      }
      print
    }
    END { if (!updated) print wanted " = \"" replacement "\"" }
  ' "$CONFIG_FILE" > "$config_temp"; then
    fail "写入 config/app.conf 失败"
  fi

  chmod 600 "$config_temp" || {
    fail "无法设置 config/app.conf 的安全权限"
  }
  mv "$config_temp" "$CONFIG_FILE" || {
    fail "无法更新 config/app.conf"
  }
  config_temp=
  rm -f "$config_secret"
  config_secret=
  trap - 0 1 2 15
  config_dir=
  config_value=
}

restore_terminal() {
  if [ -n "${saved_stty:-}" ]; then
    stty "$saved_stty" 2>/dev/null || true
  fi
}

ensure_user_token_key() {
  [ -n "$(read_config user_token_key)" ] && return 0

  if [ ! -t 0 ]; then
    fail "user_token_key 为空且当前不是交互终端。请登录 $ACCESS_TOKEN_URL 创建客户端密钥，写入 config/app.conf 后重试"
  fi

  printf '\n首次安装需要客户端密钥：\n'
  printf '  1. 登录访问控制页面：%s\n' "$ACCESS_TOKEN_URL"
  printf '  2. 在 access-tokens 页面创建客户端密钥。\n'
  printf '  3. 密钥仅完整显示一次，请立即保存，然后返回此终端。\n\n'
  printf '创建完成后按回车继续，输入 q 取消安装：'
  IFS= read -r continue_answer || fail "未读取到输入"
  case "$continue_answer" in
    q|Q) fail "已取消安装，config/app.conf 未修改" ;;
  esac

  printf '请粘贴客户端密钥（输入内容不会显示）：'
  if ! saved_stty=$(stty -g 2>/dev/null); then
    fail "无法读取终端状态"
  fi
  trap 'restore_terminal' 0
  trap 'restore_terminal; exit 130' 1 2 15
  stty -echo
  if ! IFS= read -r entered_token; then
    restore_terminal
    saved_stty=
    trap - 0 1 2 15
    printf '\n' >&2
    fail "未读取到客户端密钥"
  fi
  restore_terminal
  saved_stty=
  trap - 0 1 2 15
  printf '\n'

  case "$entered_token" in
    '') fail "客户端密钥不能为空" ;;
    *[![:graph:]]*) fail "客户端密钥不能包含空格或不可见字符" ;;
    *\"*|*\\*) fail "客户端密钥不能包含引号或反斜杠" ;;
  esac

  printf '已读取客户端密钥（%s 个字符，内容不回显）。\n' "${#entered_token}"
  printf '确认写入 config/app.conf 并继续安装？[y/N] '
  IFS= read -r confirm_answer || fail "未读取到确认结果"
  case "$confirm_answer" in
    y|Y|yes|YES|Yes) ;;
    *) fail "已取消安装，config/app.conf 未修改" ;;
  esac

  write_config_value user_token_key "$entered_token"
  entered_token=
  [ -n "$(read_config user_token_key)" ] || fail "客户端密钥写入后校验失败"
  printf '已安全写入 config/app.conf，继续安装。\n\n'
}

validate_port() {
  key=$1
  value=$(read_config "$key")
  case "$value" in
    ''|*[!0-9]*) fail "$key 必须是 1-65535 的端口" ;;
  esac
  [ "$value" -ge 1 ] && [ "$value" -le 65535 ] || fail "$key 必须是 1-65535 的端口"
  printf '%s\n' "$value"
}

port_is_listening() {
  port=$1
  if command -v ss >/dev/null 2>&1; then
    ss -H -ltn 2>/dev/null | awk -v port=":$port" '$4 ~ (port "$") { found=1 } END { exit !found }'
    return
  fi
  if command -v netstat >/dev/null 2>&1; then
    netstat -ltn 2>/dev/null | awk -v port=":$port" '$4 ~ (port "$") { found=1 } END { exit !found }'
    return
  fi
  return 1
}

[ "$(uname -s)" = "Linux" ] || fail "host 网络部署只支持 Linux Docker Engine"
case "$(uname -m)" in
  x86_64|amd64) ;;
  *) fail "当前镜像是 linux/amd64，仅支持 x86-64 服务器" ;;
esac

command -v docker >/dev/null 2>&1 || fail "未安装 Docker"
docker info >/dev/null 2>&1 || fail "Docker 服务未运行，或当前用户无访问权限"
docker compose version >/dev/null 2>&1 || fail "缺少 Docker Compose v2 插件"
[ -f "$COMPOSE_FILE" ] || fail "缺少 docker-compose.release.yml"
compose_version=$(docker compose version --short 2>/dev/null || true)
if [ -z "$compose_version" ]; then
  compose_version=$(docker compose version 2>/dev/null | sed -nE 's/.*[Vv]ersion[[:space:]]+v?([0-9]+\.[0-9]+).*/\1/p' | sed -n '1p')
fi
compose_version_supported "$compose_version" || fail "需要 Docker Compose v2.20+，当前版本为 ${compose_version:-未知}"
ensure_config_file
ensure_user_token_key

if ! command -v ss >/dev/null 2>&1 && ! command -v netstat >/dev/null 2>&1; then
  fail "缺少端口检查工具，请先安装 iproute2（提供 ss）或 net-tools（提供 netstat）"
fi

http_port=$(validate_port httpport)
websocket_port=$(validate_port websocketport)
face_port=$(validate_port pad_face_verifier_port)
redis_addr=$(read_config redislink)
case "$redis_addr" in
  127.0.0.1:*) ;;
  *) fail "redislink 必须是 127.0.0.1:独立端口，例如 127.0.0.1:16379" ;;
esac
redis_port=${redis_addr##*:}
case "$redis_port" in
  ''|*[!0-9]*) fail "redislink 端口无效" ;;
esac
[ "$redis_port" -ge 1 ] && [ "$redis_port" -le 65535 ] || fail "redislink 端口无效"

[ "$http_port" != "$websocket_port" ] || fail "httpport 与 websocketport 不能相同"
[ "$http_port" != "$face_port" ] || fail "httpport 与 pad_face_verifier_port 不能相同"
[ "$websocket_port" != "$face_port" ] || fail "websocketport 与 pad_face_verifier_port 不能相同"
for service_port in "$http_port" "$websocket_port" "$face_port"; do
  [ "$redis_port" != "$service_port" ] || fail "Redis 端口不能与业务端口重复"
done

cd "$SCRIPT_DIR"
mkdir -p data/wechatpad data/redis
docker compose -f "$COMPOSE_FILE" config --quiet
docker compose -f "$COMPOSE_FILE" pull

existing=$(docker compose -f "$COMPOSE_FILE" ps -a -q 2>/dev/null || true)
if [ -n "$existing" ]; then
  printf '正在停止当前部署，以便重新挂载最新 config/app.conf ...\n'
  docker compose -f "$COMPOSE_FILE" down --remove-orphans
fi

for port in "$http_port" "$websocket_port" "$face_port" "$redis_port"; do
  if port_is_listening "$port"; then
    fail "宿主机端口 $port 已被其他进程占用，请修改 config/app.conf 后重试"
  fi
done

if ! docker compose -f "$COMPOSE_FILE" up -d --force-recreate --remove-orphans; then
  docker compose -f "$COMPOSE_FILE" logs --tail=160 prepare redis wechatpad >&2 || true
  fail "容器启动失败"
fi

printf '正在等待 API http://127.0.0.1:%s ...\n' "$http_port"
if command -v curl >/dev/null 2>&1; then
  ready=0
  attempts=0
  while [ "$attempts" -lt 60 ]; do
    if curl -fsS --max-time 2 "http://127.0.0.1:$http_port/" >/dev/null 2>&1; then
      ready=1
      break
    fi
    attempts=$((attempts + 1))
    sleep 2
  done
  if [ "$ready" -ne 1 ]; then
    docker compose -f "$COMPOSE_FILE" logs --tail=160 prepare redis wechatpad >&2 || true
    fail "API 在 120 秒内未就绪"
  fi
else
  printf '提示：宿主机未安装 curl，已跳过 HTTP 就绪检测。\n'
fi

docker compose -f "$COMPOSE_FILE" ps
container_id=$(docker compose -f "$COMPOSE_FILE" ps -q wechatpad 2>/dev/null || true)
image_name=
image_id=
image_version=
build_id=
image_digests=
if [ -n "$container_id" ]; then
  image_name=$(docker inspect --format '{{.Config.Image}}' "$container_id" 2>/dev/null || true)
  image_id=$(docker inspect --format '{{.Image}}' "$container_id" 2>/dev/null || true)
  image_version=$(docker inspect --format '{{index .Config.Labels "org.opencontainers.image.version"}}' "$container_id" 2>/dev/null || true)
  build_id=$(docker inspect --format '{{index .Config.Labels "com.wechatpadpro.build-id"}}' "$container_id" 2>/dev/null || true)
  if [ -n "$image_id" ]; then
    image_digests=$(docker image inspect --format '{{json .RepoDigests}}' "$image_id" 2>/dev/null || true)
  fi
fi
image_name=$(metadata_or_unknown "$image_name")
image_id=$(metadata_or_unknown "$image_id")
image_version=$(metadata_or_unknown "$image_version")
build_id=$(metadata_or_unknown "$build_id")
image_digests=$(metadata_or_unknown "$image_digests")

printf '\n部署完成：\n'
printf '  本机 API/文档: http://127.0.0.1:%s/\n' "$http_port"
printf '  生产 API: https://YOUR_DOMAIN/（反向代理到 127.0.0.1:%s）\n' "$http_port"
printf '  WebSocket: 先调用 /api/Runtime/WebSocketTicket，再使用 wss://YOUR_DOMAIN/ws/sync?ticket=SHORT_LIVED_TICKET\n'
printf '  Pad 人脸代理端口: %s（仅允许实际验证手机来源 IP）\n' "$face_port"
printf '  Redis: 127.0.0.1:%s（仅宿主机回环）\n' "$redis_port"
printf '  镜像: %s\n' "$image_name"
printf '  版本: %s\n' "$image_version"
printf '  Build ID: %s\n' "$build_id"
printf '  Image ID: %s\n' "$image_id"
printf '  Repo Digests: %s\n' "$image_digests"
